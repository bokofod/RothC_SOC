install.packages("SoilR", Ncpus = 4);
install.packages("ggplot2", Ncpus = 4);
install.packages("dplyr", Ncpus = 4);
install.packages("tidyr", Ncpus = 4);
install.packages("rjson", Ncpus = 4);
install.packages("deSolve", Ncpus = 4);
install.packages("readr", Ncpus = 4);
install.packages("pracma", Ncpus = 4);
